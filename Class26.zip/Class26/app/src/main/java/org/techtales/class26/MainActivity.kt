package org.techtales.class26

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.annotation.RequiresApi

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var btnGo: Button
    private lateinit var btnGoback: Button
    private lateinit var btnForward: Button
    private lateinit var edtUrl: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webview)
        btnGo = findViewById(R.id.webview)
        btnGoback = findViewById(R.id.btnGoBack)
        btnForward = findViewById(R.id.btnForward)

        var context = this

        webView.webViewClient = MyWebViewClint()

        btnGo.setOnClickListener({
            webView.loadUrl("https://" + edtUrl.text.toString())
        })

        btnGoback.setOnClickListener({

            if (webView.goBack()) {
                webView.goBack()
                edtUrl.setText(webView.url)
            } else
                Toast.makeText(context, "No History Available", Toast.LENGTH_SHORT).show()

        })

        btnForward.setOnClickListener({
            if (webView.canGoForward()) {
                webView.goForward()
                edtUrl.setText((webView.url))
            } else
                Toast.makeText(context, "No History Available", Toast.LENGTH_SHORT).show()
        })


    }

    class MyWebViewClint: WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            view?.loadUrl(request?.url.toString())
                return true
        }

        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
            view.loadUrl(url!!)
            return true
        }

    }

}
